# IRSeC_Toolkit_Repo

Windows PowerShell toolkit for IRSEC competition.
Safe defaults: --dry-run for non-destructive testing, centralized config.json, logging to ./logs.

Quick run examples:
  .\scripts\00_baseline_snapshot.ps1 --output .\snapshots --dry-run
  .\scripts\01_service_delta.ps1 --baseline .\snapshots\services_baseline.json --dry-run
  .\scripts\02_event_detector.ps1 --minutes 30 --dry-run
  .\scripts\03_process_triage.ps1 --baseline .\snapshots\processes_baseline.json --dry-run
  .\scripts\04_evidence_packager.ps1 --source .\evidence_to_package --out .\evidence.zip

Edit config.json before enabling auto-remediate actions.
